<?php

declare(strict_types=1);

namespace Kenzi\WooCommerce\Admin;

use Kenzi\WooCommerce\Settings;
use WC_Settings_Page;

/**
 * WooCommerce Settings tab for Kenzi Chat.
 *
 * Renders custom HTML for OAuth connect flow instead of using
 * standard WooCommerce settings fields.
 */
class SettingsPage extends WC_Settings_Page
{
    public function __construct()
    {
        $this->id = 'kenzi';
        $this->label = __('Kenzi', 'kenzi-chat');

        parent::__construct();

        add_action('woocommerce_settings_' . $this->id, [$this, 'output']);
        add_action('woocommerce_settings_save_' . $this->id, [$this, 'save']);
    }

    /**
     * Get settings array - not used since we render custom HTML.
     *
     * @return array<int, array<string, mixed>>
     */
    public function get_settings(): array
    {
        return [];
    }

    /**
     * Output the settings page with OAuth connect UI.
     */
    public function output(): void
    {
        $isConnected = Settings::isConnected();
        $widgetEnabled = Settings::isWidgetEnabled();
        $workspaceDisplay = Settings::getWorkspaceDisplay();
        $baseUrl = Settings::getBaseUrl();
        $connectUrl = Settings::getConnectUrl();
        $storeUrl = home_url();
        $adminAjaxUrl = admin_url('admin-ajax.php');
        $settingsUrl = admin_url('admin.php?page=wc-settings&tab=kenzi');
        $saveNonce = wp_create_nonce('kenzi_save_connection');
        $resetNonce = wp_create_nonce('kenzi_reset_settings');
        $formNonce = wp_create_nonce('kenzi_save_widget_settings');

        ?>
        <h2><?php esc_html_e('Connection', 'kenzi-chat'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e('Workspace', 'kenzi-chat'); ?></th>
                <td>
                    <?php if ($isConnected): ?>
                        <p style="margin: 0 0 10px; color: #2e7d32;">
                            <span class="dashicons dashicons-yes-alt" style="color: #2e7d32;"></span>
                            <?php
                            printf(
                                /* translators: %s: workspace name */
                                esc_html__('Connected to: %s', 'kenzi-chat'),
                                '<strong>' . esc_html($workspaceDisplay) . '</strong>'
                            );
                        ?>
                        </p>
                        <button type="button" class="button" onclick="kenziConnect()">
                            <?php esc_html_e('Change Workspace', 'kenzi-chat'); ?>
                        </button>
                    <?php else: ?>
                        <p style="margin: 0 0 10px;">
                            <?php esc_html_e('Connect your store to a Kenzi workspace to enable chat.', 'kenzi-chat'); ?>
                        </p>
                        <button type="button" class="button button-primary" onclick="kenziConnect()">
                            <?php esc_html_e('Connect to Kenzi', 'kenzi-chat'); ?>
                        </button>
                    <?php endif; ?>
                </td>
            </tr>
        </table>

        <h2><?php esc_html_e('Status', 'kenzi-chat'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e('Workspace', 'kenzi-chat'); ?></th>
                <td>
                    <span style="color: <?php echo $isConnected ? '#2e7d32' : '#999'; ?>;">
                        <?php echo $isConnected ? esc_html($workspaceDisplay) : esc_html__('Not connected', 'kenzi-chat'); ?>
                    </span>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Widget', 'kenzi-chat'); ?></th>
                <td>
                    <span style="color: <?php echo $widgetEnabled ? '#2e7d32' : '#999'; ?>;">
                        <?php echo $widgetEnabled ? esc_html__('Active', 'kenzi-chat') : esc_html__('Inactive', 'kenzi-chat'); ?>
                    </span>
                </td>
            </tr>
            <?php
            // TODO: Webhook support
            // <tr>
            //     <th scope="row"><?php esc_html_e('Webhooks', 'kenzi-chat');?></th>
            //     <td>...</td>
            // </tr>
            ?>
        </table>

        <h2><?php esc_html_e('Widget Settings', 'kenzi-chat'); ?></h2>
        <form method="post" action="">
            <?php wp_nonce_field('kenzi_save_widget_settings', '_kenzi_widget_nonce'); ?>
            <input type="hidden" name="kenzi_save_widget" value="1">
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Enable Widget', 'kenzi-chat'); ?></th>
                    <td>
                        <label>
                            <input type="checkbox"
                                   name="widget_enabled"
                                   value="1"
                                   <?php checked($widgetEnabled); ?>
                                   <?php disabled(! $isConnected); ?>>
                            <?php esc_html_e('Show Kenzi chat widget on your store', 'kenzi-chat'); ?>
                        </label>
                        <p class="description">
                            <?php if (! $isConnected): ?>
                                <span style="color: #d63638;">
                                    <?php esc_html_e('Connect to Kenzi first to enable the widget.', 'kenzi-chat'); ?>
                                </span>
                            <?php else: ?>
                                <?php esc_html_e('When enabled, the chat widget appears on all pages.', 'kenzi-chat'); ?>
                            <?php endif; ?>
                        </p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <button type="submit" class="button button-primary">
                    <?php esc_html_e('Save Changes', 'kenzi-chat'); ?>
                </button>
            </p>
        </form>

        <h2><?php esc_html_e('Developer Tools', 'kenzi-chat'); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e('Base URL', 'kenzi-chat'); ?></th>
                <td>
                    <form method="post" action="" style="margin: 0;">
                        <?php wp_nonce_field('kenzi_save_widget_settings', '_kenzi_widget_nonce'); ?>
                        <input type="hidden" name="kenzi_save_base_url" value="1">
                        <input type="text"
                               name="base_url"
                               value="<?php echo esc_attr($baseUrl); ?>"
                               class="regular-text"
                               placeholder="<?php echo esc_attr(Settings::DEFAULT_BASE_URL); ?>">
                        <button type="submit" class="button"><?php esc_html_e('Update', 'kenzi-chat'); ?></button>
                        <p class="description">
                            <?php esc_html_e('Change for local development or staging. Default:', 'kenzi-chat'); ?>
                            <code><?php echo esc_html(Settings::DEFAULT_BASE_URL); ?></code>
                        </p>
                    </form>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e('Reset', 'kenzi-chat'); ?></th>
                <td>
                    <button type="button" class="button" style="color: #d63638; border-color: #d63638;" onclick="kenziReset()">
                        <?php esc_html_e('Reset All Settings', 'kenzi-chat'); ?>
                    </button>
                    <p class="description">
                        <?php esc_html_e('Disconnect workspace and reset all settings to defaults.', 'kenzi-chat'); ?>
                    </p>
                </td>
            </tr>
        </table>

        <script>
        (function() {
            let currentNonce = null;

            window.kenziConnect = function() {
                const bytes = new Uint8Array(32);
                crypto.getRandomValues(bytes);
                currentNonce = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');

                const storeUrl = <?php echo wp_json_encode($storeUrl); ?>;
                const connectUrl = <?php echo wp_json_encode($connectUrl); ?> + '?' + new URLSearchParams({
                    platform: 'woocommerce',
                    store_key: storeUrl,
                    origin: storeUrl,
                    nonce: currentNonce
                });

                const width = 500, height = 600;
                const left = Math.round((screen.width - width) / 2);
                const top = Math.round((screen.height - height) / 2);
                const popup = window.open(
                    connectUrl,
                    'kenzi_connect',
                    `popup,width=${width},height=${height},left=${left},top=${top},scrollbars=yes,resizable=yes`
                );

                if (!popup || popup.closed) {
                    alert(<?php echo wp_json_encode(__('Popup was blocked. Please allow popups for this site.', 'kenzi-chat')); ?>);
                    currentNonce = null;
                }
            };

            window.kenziReset = function() {
                if (!confirm(<?php echo wp_json_encode(__('Reset all Kenzi Chat settings? This will disconnect your workspace.', 'kenzi-chat')); ?>)) {
                    return;
                }

                fetch(<?php echo wp_json_encode($adminAjaxUrl); ?>, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'kenzi_reset_settings',
                        _wpnonce: <?php echo wp_json_encode($resetNonce); ?>
                    })
                })
                .then(r => r.json())
                .then(result => {
                    if (result.success) {
                        window.location.href = <?php echo wp_json_encode($settingsUrl); ?>;
                    } else {
                        alert(<?php echo wp_json_encode(__('Reset failed:', 'kenzi-chat')); ?> + ' ' + (result.data || 'Unknown error'));
                    }
                })
                .catch(() => alert(<?php echo wp_json_encode(__('Reset failed. Please try again.', 'kenzi-chat')); ?>));
            };

            window.addEventListener('message', function(event) {
                const expectedOrigin = new URL(<?php echo wp_json_encode($connectUrl); ?>).origin;
                if (event.origin !== expectedOrigin) {
                    return;
                }

                if (event.data?.type === 'kenzi_connected') {
                    if (event.data.nonce !== currentNonce) {
                        alert(<?php echo wp_json_encode(__('Security validation failed. Please try again.', 'kenzi-chat')); ?>);
                        return;
                    }

                    if (event.source && typeof event.source.close === 'function') {
                        event.source.close();
                    }
                    currentNonce = null;

                    fetch(<?php echo wp_json_encode($adminAjaxUrl); ?>, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({
                            action: 'kenzi_save_connection',
                            _wpnonce: <?php echo wp_json_encode($saveNonce); ?>,
                            workspace_id: event.data.workspace_id || '',
                            workspace_name: event.data.workspace_name || '',
                            widget_url: event.data.widget_url || '',
                            webhook_secret: event.data.webhook_secret || '',
                            callback_token: event.data.callback_token || ''
                        })
                    })
                    .then(r => r.json())
                    .then(result => {
                        if (result.success) {
                            window.location.href = <?php echo wp_json_encode($settingsUrl . '&connected=1'); ?>;
                        } else {
                            alert(<?php echo wp_json_encode(__('Failed to save connection:', 'kenzi-chat')); ?> + ' ' + (result.data || 'Unknown error'));
                        }
                    })
                    .catch(() => alert(<?php echo wp_json_encode(__('Failed to save connection. Please try again.', 'kenzi-chat')); ?>));
                }
            });
        })();
        </script>

        <?php if (isset($_GET['connected'])): ?>
        <script>
            // Show success notice
            const notice = document.createElement('div');
            notice.className = 'notice notice-success is-dismissible';
            notice.innerHTML = '<p><?php echo esc_js(__('Successfully connected to Kenzi!', 'kenzi-chat')); ?></p>';
            document.querySelector('.wrap h1')?.after(notice);
        </script>
        <?php endif; ?>
        <?php
    }

    /**
     * Save settings from form POST.
     */
    public function save(): void
    {
        // Handle widget enabled toggle
        if (isset($_POST['kenzi_save_widget']) && $_POST['kenzi_save_widget'] === '1') {
            if (! wp_verify_nonce($_POST['_kenzi_widget_nonce'] ?? '', 'kenzi_save_widget_settings')) {
                return;
            }

            Settings::setWidgetEnabled(isset($_POST['widget_enabled']));
        }

        // Handle base URL update
        if (isset($_POST['kenzi_save_base_url']) && $_POST['kenzi_save_base_url'] === '1') {
            if (! wp_verify_nonce($_POST['_kenzi_widget_nonce'] ?? '', 'kenzi_save_widget_settings')) {
                return;
            }

            $baseUrl = isset($_POST['base_url']) ? esc_url_raw(trim($_POST['base_url'])) : '';
            Settings::setBaseUrl($baseUrl);
        }
    }
}
