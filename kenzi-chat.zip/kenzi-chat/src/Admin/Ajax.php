<?php

declare(strict_types=1);

namespace Kenzi\WooCommerce\Admin;

use Kenzi\WooCommerce\Settings;

/**
 * AJAX handlers for Kenzi Chat admin actions.
 */
final class Ajax
{
    /**
     * Register AJAX action hooks.
     */
    public static function register(): void
    {
        add_action('wp_ajax_kenzi_save_connection', [self::class, 'saveConnection']);
        add_action('wp_ajax_kenzi_reset_settings', [self::class, 'resetSettings']);
    }

    /**
     * Handle connection save from OAuth popup flow.
     */
    public static function saveConnection(): void
    {
        if (! current_user_can('manage_woocommerce')) {
            wp_send_json_error('Unauthorized');
        }

        if (! wp_verify_nonce($_POST['_wpnonce'] ?? '', 'kenzi_save_connection')) {
            wp_send_json_error('Invalid nonce');
        }

        Settings::saveConnection([
            'workspace_id' => $_POST['workspace_id'] ?? '',
            'workspace_name' => $_POST['workspace_name'] ?? '',
            'widget_url' => $_POST['widget_url'] ?? '',
            'webhook_secret' => $_POST['webhook_secret'] ?? '',
            'callback_token' => $_POST['callback_token'] ?? '',
        ]);

        wp_send_json_success();
    }

    /**
     * Handle settings reset (disconnect workspace).
     */
    public static function resetSettings(): void
    {
        if (! current_user_can('manage_woocommerce')) {
            wp_send_json_error('Unauthorized');
        }

        if (! wp_verify_nonce($_POST['_wpnonce'] ?? '', 'kenzi_reset_settings')) {
            wp_send_json_error('Invalid nonce');
        }

        Settings::reset();

        wp_send_json_success();
    }
}
