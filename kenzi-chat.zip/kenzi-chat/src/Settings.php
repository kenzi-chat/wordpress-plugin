<?php

declare(strict_types=1);

namespace Kenzi\WooCommerce;

/**
 * Settings helper for Kenzi Chat plugin options.
 */
final class Settings
{
    public const OPTION_NAME = 'kenzi_chat_settings';
    public const BASE_URL_OPTION = 'kenzi_base_url';
    public const DEFAULT_BASE_URL = 'https://app.kenzi.chat';

    /**
     * Get all settings with defaults.
     *
     * @return array{
     *     workspace_id: string,
     *     workspace_name: string,
     *     widget_url: string,
     *     webhook_secret: string,
     *     callback_token: string,
     *     widget_enabled: bool
     * }
     */
    public static function get(): array
    {
        $defaults = [
            'workspace_id' => '',
            'workspace_name' => '',
            'widget_url' => '',
            'webhook_secret' => '',
            'callback_token' => '',
            'widget_enabled' => false,
        ];

        /** @var array<string, mixed> $options */
        $options = get_option(self::OPTION_NAME, []);

        return array_merge($defaults, $options);
    }

    /**
     * Get the Kenzi base URL (for connect flow and postMessage validation).
     */
    public static function getBaseUrl(): string
    {
        $url = get_option(self::BASE_URL_OPTION, '');

        return is_string($url) && $url !== '' ? $url : self::DEFAULT_BASE_URL;
    }

    /**
     * Set the Kenzi base URL.
     */
    public static function setBaseUrl(string $url): void
    {
        $url = trim($url);

        if ($url === '' || $url === self::DEFAULT_BASE_URL) {
            delete_option(self::BASE_URL_OPTION);
        } else {
            update_option(self::BASE_URL_OPTION, $url);
        }
    }

    /**
     * Get the full connect URL for OAuth popup.
     */
    public static function getConnectUrl(): string
    {
        return rtrim(self::getBaseUrl(), '/') . '/connect';
    }

    /**
     * Check if a workspace is connected.
     */
    public static function isConnected(): bool
    {
        $options = self::get();

        return $options['workspace_id'] !== '';
    }

    /**
     * Check if the widget is enabled (and connected).
     */
    public static function isWidgetEnabled(): bool
    {
        $options = self::get();

        return self::isConnected() && ! empty($options['widget_enabled']);
    }

    /**
     * Get the widget URL if available.
     */
    public static function getWidgetUrl(): ?string
    {
        $options = self::get();

        return $options['widget_url'] !== '' ? $options['widget_url'] : null;
    }

    /**
     * Get the workspace display name.
     */
    public static function getWorkspaceDisplay(): string
    {
        $options = self::get();

        return $options['workspace_name'] !== '' ? $options['workspace_name'] : $options['workspace_id'];
    }

    /**
     * Save connection data from OAuth flow.
     *
     * @param array<string, string> $data
     */
    public static function saveConnection(array $data): void
    {
        $options = self::get();

        $options['workspace_id'] = sanitize_text_field($data['workspace_id'] ?? '');
        $options['workspace_name'] = sanitize_text_field($data['workspace_name'] ?? '');
        $options['widget_url'] = esc_url_raw($data['widget_url'] ?? '');
        $options['webhook_secret'] = sanitize_text_field($data['webhook_secret'] ?? '');
        $options['callback_token'] = sanitize_text_field($data['callback_token'] ?? '');

        update_option(self::OPTION_NAME, $options);
    }

    /**
     * Save widget enabled state.
     */
    public static function setWidgetEnabled(bool $enabled): void
    {
        $options = self::get();

        // Can only enable if connected
        $options['widget_enabled'] = self::isConnected() && $enabled;

        update_option(self::OPTION_NAME, $options);
    }

    /**
     * Reset all settings (disconnect workspace).
     */
    public static function reset(): void
    {
        delete_option(self::OPTION_NAME);
    }
}
