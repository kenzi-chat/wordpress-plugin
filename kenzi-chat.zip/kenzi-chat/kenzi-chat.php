<?php

/**
 * Plugin Name: Kenzi Chat
 * Plugin URI:  https://kenzi.chat
 * Description: Add the Kenzi chat widget to your WooCommerce store for customer messaging powered by real-time order and customer data.
 * Version:     1.0.0
 * Author:      Kenzi
 * Author URI:  https://kenzi.chat
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: kenzi-chat
 * Requires at least: 6.0
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce
 * WC requires at least: 8.0
 * WC tested up to: 9.6
 *
 * @package Kenzi\WooCommerce
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

define('KENZI_CHAT_VERSION', '1.0.0');
define('KENZI_CHAT_PLUGIN_FILE', __FILE__);
define('KENZI_CHAT_PLUGIN_DIR', plugin_dir_path(__FILE__));

require_once __DIR__ . '/vendor/autoload.php';

use Kenzi\WooCommerce\Plugin;

add_action('plugins_loaded', static function (): void {
    if (! class_exists(\WooCommerce::class)) {
        add_action('admin_notices', static function (): void {
            echo '<div class="error"><p>';
            echo esc_html__('Kenzi Chat requires WooCommerce to be installed and active.', 'kenzi-chat');
            echo '</p></div>';
        });

        return;
    }

    Plugin::instance()->init();
});

add_action('before_woocommerce_init', static function (): void {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// TODO: Webhook support
// register_deactivation_hook(__FILE__, static function (): void {
//     Plugin::instance()->removeWebhooks();
// });
